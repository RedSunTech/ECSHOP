<?php

$_LANG['suntech711']          = '7-11統一超商';
$_LANG['suntech711_desc']     = '必須搭配紅陽支付。';

$_LANG['suntechfamily']          = '全家超商';
$_LANG['suntechfamily_desc']     = '必須搭配紅陽支付。';

$_LANG['suntechfamilyB']          = '全家超商(大宗)';
$_LANG['suntechfamilyB_desc']     = '必須搭配紅陽支付。';

$_LANG['suntechhilife']          = '萊爾富';
$_LANG['suntechhilife_desc']     = '必須搭配紅陽支付。';

$_LANG['suntechokmart']          = 'OK超商';
$_LANG['suntechokmart_desc']     = '必須搭配紅陽支付。';

$_LANG['suntechecan']          = '宅配通';
$_LANG['suntechecan_desc']     = '必須搭配紅陽支付。';
$_LANG['suntech_EDI_Size']     = '包裹尺寸';
$_LANG['suntech_EDI_Type']     = '包裹類別';

$_LANG['base_fee']      = '運費：';
$_LANG['free_money'] = '免運額度：';

